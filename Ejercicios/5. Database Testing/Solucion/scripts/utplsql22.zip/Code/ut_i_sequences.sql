@@ut_i_run ut_suite_seq.seq
@@ut_i_run ut_package_seq.seq
@@ut_i_run ut_utp_seq.seq
@@ut_i_run ut_test_seq.seq
@@ut_i_run ut_unittest_seq.seq
@@ut_i_run ut_testcase_seq.seq
@@ut_i_run ut_plsql_runnum_seq.seq
@@ut_i_run ut_assertion_seq.seq
@@ut_i_run ut_receq_seq.seq
@@ut_i_run ut_refcursor_results_seq.seq


