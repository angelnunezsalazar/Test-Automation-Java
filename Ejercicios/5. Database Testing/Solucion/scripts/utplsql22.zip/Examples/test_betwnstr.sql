begin
   utplsql.test ('betwnstr');
end;
